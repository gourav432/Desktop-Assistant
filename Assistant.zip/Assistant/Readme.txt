Double click on assistant.exe file 
A gui will be opened 
Press RUN button
Say okay karen or wake up karen to turn on your desktop assistant




FEATURES OF KAREN

1.  Wishing timewise
2.  Sending mails
3.  Searching something on Google
4.  Searching something on Youtube
5.  Opening specific Websites
6.  Opening specific Apps
7.  News of live score
8.  Playing music
9.  Speaking Date and Time
10. Fetching results from wikipedia
11. Battery percentage of system
12. Sending text messages
13. Making phone calls
14. Volume control of system
15. Setting alarm
16. Checking internet speed
17. Sending messages in whatsapp
18. Searching anything from browser
